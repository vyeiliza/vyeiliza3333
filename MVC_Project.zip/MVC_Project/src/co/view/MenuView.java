package co.view;

public class MenuView {
    public static void menu(){
        System.out.println( "1. List Product");
        System.out.println("2. Create Product");
        System.out.println("3. Delete Product");
        System.out.println("4. update Product");
    }
}
