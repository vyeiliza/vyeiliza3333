package co.controller;

import co.view.MenuView;

public class MenuController {
    public static  void index (){
        MenuView.menu();
    }
}
